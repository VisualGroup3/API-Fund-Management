package com.group3.fundmgt.fund;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FundService {
    private final FundRepository fundRepository;

    @Autowired
    public FundService(FundRepository fundRepository) {
        this.fundRepository = fundRepository;
    }

    public List<Fund> getFunds(){return fundRepository.findAll();}

    public Fund getFund(Integer fundId){
        Optional<Fund> fund = fundRepository.findById(fundId);
        if (fund.isEmpty()){
            throw new FundNotFoundException(fundId);
        }
        return fund.get();
    }
}
