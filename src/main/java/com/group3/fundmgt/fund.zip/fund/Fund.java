package com.group3.fundmgt.fund;

import javax.persistence.*;

@Entity
@Table
public class Fund {
    // 1.建表
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer fundId;

    @Column(nullable = false)
    private String name;

    // 2.生成构造方法
    public Fund(){}

    public Fund(Integer fundId, String name) {
        this.fundId = fundId;
        this.name = name;
    }

    public Fund(String name) {
        this.name = name;
    }

    // 3.生成set和get和toString方法
    public Integer getFundId() {
        return fundId;
    }

    public void setFundId(Integer fundId) {
        this.fundId = fundId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Fund{" +
                "fundId=" + fundId +
                ", name='" + name + '\'' +
                '}';
    }
}
