package com.group3.fundmgt.fund;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "/api/v1/funds")
public class FundController {
    private final FundService fundService;

    @Autowired
    public FundController(FundService fundService) {
        this.fundService = fundService;
    }

    @GetMapping
    public List<Fund> getFund(){return fundService.getFunds();}

    @GetMapping(path = "{fundId}")
    public Fund getFund(@PathVariable("fundId") Integer fundId){
        return fundService.getFund(fundId);
    }
}
